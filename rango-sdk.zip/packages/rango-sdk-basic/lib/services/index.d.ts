export { RangoClient } from './client';
//# sourceMappingURL=index.d.ts.map