export declare const httpService: import("axios").AxiosInstance;
