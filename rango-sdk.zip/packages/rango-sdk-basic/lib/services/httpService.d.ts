export declare const httpService: import("axios").AxiosInstance;
//# sourceMappingURL=httpService.d.ts.map