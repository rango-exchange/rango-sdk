import { MetaResponse, BestRouteRequest, BestRouteResponse, CheckApprovalResponse, CheckTxStatusRequest, TransactionStatusResponse, CreateTransactionRequest, CreateTransactionResponse, ReportTransactionRequest, WalletDetailsResponse } from '../types';
declare type WalletAddresses = {
    blockchain: string;
    address: string;
}[];
export declare class RangoClient {
    private readonly deviceId;
    private readonly apiKey;
    constructor(apiKey: string);
    getAllMetadata(): Promise<MetaResponse>;
    getBestRoute(requestBody: BestRouteRequest): Promise<BestRouteResponse>;
    checkApproval(requestId: string): Promise<CheckApprovalResponse>;
    checkStatus(requestBody: CheckTxStatusRequest): Promise<TransactionStatusResponse>;
    createTransaction(requestBody: CreateTransactionRequest): Promise<CreateTransactionResponse>;
    reportFailure(requestBody: ReportTransactionRequest): Promise<void>;
    getWalletsDetails(walletAddresses: WalletAddresses): Promise<WalletDetailsResponse>;
}
export {};
//# sourceMappingURL=client.d.ts.map