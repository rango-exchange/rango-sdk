import { MetaResponse, QuoteRequest, QuoteResponse, CheckApprovalResponse, StatusRequest, StatusResponse, SwapRequest, SwapResponse, ReportTransactionRequest, WalletDetailsResponse } from '../types';
declare type WalletAddress = {
    blockchain: string;
    address: string;
};
export declare class RangoClient {
    private readonly deviceId;
    private readonly apiKey;
    constructor(apiKey: string, debug?: boolean);
    meta(): Promise<MetaResponse>;
    quote(quoteRequest: QuoteRequest): Promise<QuoteResponse>;
    isApproved(requestId: string, txId: string): Promise<CheckApprovalResponse>;
    status(statusRequest: StatusRequest): Promise<StatusResponse>;
    swap(swapRequest: SwapRequest): Promise<SwapResponse>;
    reportFailure(requestBody: ReportTransactionRequest): Promise<void>;
    balance(walletAddress: WalletAddress): Promise<WalletDetailsResponse>;
}
export {};
//# sourceMappingURL=client.d.ts.map